import{e as i,g as o,j as n,u as a}from"./index-DPAejswI.js";/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=i("ShieldAlert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]),c="*";function u(e,s){return e.includes(s)||e.includes(c)}function m(){const e=o(s=>s.permissions);return{permissions:e,can:s=>u(e,s)}}function l({code:e}){const{t:s}=a();return n.jsxs("div",{className:"flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed p-8 text-center text-muted-foreground","data-testid":"permission-denied","data-permission-code":e,children:[n.jsx(d,{className:"h-6 w-6"}),n.jsx("p",{className:"text-sm",children:s("common.permissionDenied",{code:e})})]})}function h({code:e,children:s,fallback:t}){const{can:r}=m();return r(e)?n.jsx(n.Fragment,{children:s}):n.jsx(n.Fragment,{children:t===void 0?n.jsx(l,{code:e}):t})}export{h as R,m as u};
//# sourceMappingURL=RequirePermission-TxpD2mo-.js.map
