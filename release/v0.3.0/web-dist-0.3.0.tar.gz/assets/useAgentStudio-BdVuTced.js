import{h as a,l as n,V as t,bj as s}from"./index-DPAejswI.js";function r(){const i=a();return n({mutationFn:e=>s.publishDraft(e.id,e.draft),onSuccess:e=>{i.invalidateQueries({queryKey:t.agent(e.agent_id)}),i.invalidateQueries({queryKey:t.agentVersions(e.agent_id)}),i.invalidateQueries({queryKey:t.agents})}})}export{r as u};
//# sourceMappingURL=useAgentStudio-BdVuTced.js.map
