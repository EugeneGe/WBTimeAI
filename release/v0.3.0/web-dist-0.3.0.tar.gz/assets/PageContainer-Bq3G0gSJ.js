import{j as n,s as e}from"./index-DPAejswI.js";const o={default:"max-w-[1152px]",content:"max-w-[1280px]",wide:"max-w-[1600px]",full:"w-full max-w-none"};function l({width:a="default",className:t,children:x}){return n.jsx("div",{className:e("mx-auto w-full px-4 py-6",o[a],t),children:x})}export{l as P};
//# sourceMappingURL=PageContainer-Bq3G0gSJ.js.map
