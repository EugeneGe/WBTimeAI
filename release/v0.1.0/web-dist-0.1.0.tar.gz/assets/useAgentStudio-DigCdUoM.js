import{h as a,l as n,X as t,bk as s}from"./index-QvuNvm3j.js";function r(){const i=a();return n({mutationFn:e=>s.publishDraft(e.id,e.draft),onSuccess:e=>{i.invalidateQueries({queryKey:t.agent(e.agent_id)}),i.invalidateQueries({queryKey:t.agentVersions(e.agent_id)}),i.invalidateQueries({queryKey:t.agents})}})}export{r as u};
//# sourceMappingURL=useAgentStudio-DigCdUoM.js.map
