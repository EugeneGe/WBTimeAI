import{j as n,w as e}from"./index-QvuNvm3j.js";const o={default:"max-w-[1152px]",content:"max-w-[1280px]",wide:"max-w-[1600px]",full:"w-full max-w-none"};function m({width:a="default",className:t,children:x}){return n.jsx("div",{className:e("mx-auto w-full px-4 py-6",o[a],t),children:x})}export{m as P};
//# sourceMappingURL=PageContainer-8GBseR9D.js.map
